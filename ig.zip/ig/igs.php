<?php error_reporting(0); function 
sdata($url , $custom = null, $delCookies = 
null){
     $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_HEADER, 
false);
      if($custom[uagent]){
        curl_setopt($ch, CURLOPT_USERAGENT, 
$custom[uagent]);
      }else{
      curl_setopt($ch, CURLOPT_USERAGENT, 
"msnbot/1.0 
(+http://search.msn.com/msnbot.htm)");
      }
      curl_setopt($ch, 
CURLOPT_FOLLOWLOCATION, true);
      curl_setopt($ch, 
CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, 
CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, 
CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, 
CURLOPT_CONNECTTIMEOUT ,0);
      curl_setopt($ch, CURLOPT_ENCODING , 
"gzip");
      if($custom[rto]){
        curl_setopt($ch, CURLOPT_TIMEOUT, 
$timeout);
      }else{
        curl_setopt($ch, CURLOPT_TIMEOUT, 
60);
      }
      if($custom[header]){
        curl_setopt($ch, 
CURLOPT_HTTPHEADER, $custom[header]);
      }
      curl_setopt($ch, CURLOPT_COOKIEJAR, 
'instagram.txt');
      curl_setopt($ch, CURLOPT_COOKIEFILE, 
'instagram.txt');
      curl_setopt($ch, CURLOPT_VERBOSE, 
false);
      if($custom[cpost]){
      	curl_setopt($ch, CURLOPT_POST, 
true);
      }
      if($custom[post]){
        if(is_array($custom[post])){
          $query = 
http_build_query($custom[post]);
          }else{
          $query = $custom[post];
        }
        curl_setopt($ch, CURLOPT_POST, 
true);
        curl_setopt($ch, 
CURLOPT_POSTFIELDS, $query);
      }
      $data = curl_exec($ch);
      $httpcode = curl_getinfo($ch, 
CURLINFO_HTTP_CODE);
      curl_close($ch);
      if($delCookies != false){
          unlink("cookijem.txt");
      }
      return array(
        'data' => $data,
        'decode' => json_decode($data , 
true),
        'httpcode' => $httpcode
      );
}
function follow($array){
	$limit = 2;
	$coun = 1;
	$couns = 1;
	$c = count($array);
	foreach ($array as $key => $detail) 
{
		$csrf = 
sdata('https://www.instagram.com/'.$detail['username'].'/');
		
preg_match_all('/"csrf_token": "(.*?)"/', 
$csrf['data'], $token);
		$follow = 
sdata("https://www.instagram.com/web/friendships/".$detail['id']."/follow/",
		array(
			'header' => array(
			    "cache-control: 
no-cache",
			    "connection: 
keep-alive",
			    "content-type: 
application/x-www-form-urlencoded",
			    "host: 
www.instagram.com",
			    "origin: 
https://www.instagram.com",
			    "referer: 
".'https://www.instagram.com/'.$detail['username'].'/',
			    "user-agent: 
Mozilla/5.0 (Windows NT 10.0; Win64; x64) 
AppleWebKit/537.36 (KHTML, like Gecko) 
Chrome/62.0.3202.94 Safari/537.36",
			    "x-csrftoken: 
".$token[1][0],
			    
"x-instagram-ajax: 1",
			    
"x-requested-with: XMLHttpRequest"
			  ),
			'cpost' => true,
	    ));
	  	if( $follow['httpcode'] == 
'403' ){
	    	echo "[Respons] Server 
sibuk ...\r\n";
	    	sleep(300);
	    }else{
	    	echo "[IG 
Master][".$couns."  <> ".$c."] 
".$detail['name']."(".$detail['username'].") 
=> ".$follow['decode']['result']." 
[".$detail['count']['count']."]\r\n";
	    }
		if($limit == $coun){
			sleep(20);
			$coun = 1;
		}
	    $coun++;
	    $couns++;
	}
}
unlink('instagram.txt'); $csrf = 
sdata("https://www.instagram.com/accounts/login/"); 
$csrf = preg_match_all('/"csrf_token": 
"(.*?)"/', $csrf['data'], $token); $login = 
sdata("https://www.instagram.com/accounts/login/ajax/",
	array(
		'header' => array(
		    "connection: 
keep-alive",
		    "content-type: 
application/x-www-form-urlencoded",
		    "host: 
www.instagram.com",
		    "origin: 
https://www.instagram.com",
		    "referer: 
https://www.instagram.com/accounts/login/",
		    "user-agent: 
Mozilla/5.0 (Windows NT 10.0; Win64; x64) 
AppleWebKit/537.36 (KHTML, like Gecko) 
Chrome/62.0.3202.94 Safari/537.36",
		    "x-csrftoken: 
".$token[1][0],
		    "x-instagram-ajax: 1",
		    "x-requested-with: 
XMLHttpRequest"),
		'post' => 
'username=xxxx&password=xxx',
    )); if( $login[decode][authenticated] 
){
	echo "[ -- Login Success -- ]\r\n";
	$userIG = array();
	while (true) {
		echo "[ -- Search accounts 
".$i." -- ]\r\n";
		/*
		$fetch = 
sdata('https://www.instagram.com/graphql/query/?query_id=17847560125201451&variables={%22fetch_media_count%22:0,%22fetch_suggested_count%22:100,%22ignore_cache%22:true,%22filter_followed_friends%22:true,%22seen_ids%22:[]}');
		foreach 
($fetch['decode']['data']['user']['edge_suggested_user']['edges'] 
as $key => $value) {
			
if($value['node']['is_private'] == 0 && 
$value['node']['requested_by_viewer'] == 0 
&& $value['node']['edge_followed_by'] >= 
1000){
				$userIG[] = 
array(
					
'count' => 
$value['node']['edge_followed_by'],
					
'name' => $value['node']['full_name'],
					
'id' => $value['node']['id'],
					
'username' => $value['node']['username'],
				);
			}
		}
		*/
		
		$fetch = 
sdata('https://www.instagram.com/graphql/query/?query_id=17851374694183129&variables={%22id%22:%22522969993%22,%22first%22:3000}');
		foreach 
($fetch['decode']['data']['user']['edge_followed_by']['edges'] 
as $key => $value) {
			
if($value['node']['is_private'] == 0 && 
$value['node']['requested_by_viewer'] == 
0){
				$userIG[] = 
array(
					
'count' => '1K',
					
'name' => $value['node']['full_name'],
					
'id' => $value['node']['id'],
					
'username' => $value['node']['username'],
				);
			}
		}
		follow($userIG);
	}
}
